# memer

### this app lets you search memes

- create-react-app memer
- npm install @material-ui/core --save
- npm start